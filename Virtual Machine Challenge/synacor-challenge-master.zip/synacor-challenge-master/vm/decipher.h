#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

void decipher(uint16_t *memory);

void printVar(FILE *fp, uint16_t a);